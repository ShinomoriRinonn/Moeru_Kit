
#内容图示

##Volume 07 表面着色器的写法(二)：自定义光照模式
<br>
### 0.内置的漫反射光照
![](http://img.blog.csdn.net/20150111162256968?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcG9lbV9xaWFubW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
<br><br> <br> 

### 1.简单的高光光照模型
![](http://img.blog.csdn.net/20150111162510361?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcG9lbV9xaWFubW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)

<br> <br> <br> 
### 2.自制简单的Lambert光照
![](http://img.blog.csdn.net/20150111162615476?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcG9lbV9xaWFubW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
<br> <br> <br>
### 3.自定义的半Lambert光照
![](http://img.blog.csdn.net/20150111162728812?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcG9lbV9xaWFubW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
<br> <br> <br> 
### 4.自定义卡通渐变光照
第一组：

![](http://img.blog.csdn.net/20150111163034155)

![](http://img.blog.csdn.net/20150111163051456)

 第二组：

![](http://img.blog.csdn.net/20150111163206149)

![](http://img.blog.csdn.net/20150111163224432)

第三组：

![](http://img.blog.csdn.net/20150111163303978)

![](http://img.blog.csdn.net/20150111163326442)


<br> <br> <br> 
### 5.自定义卡通渐变光照v2
![](http://img.blog.csdn.net/20150111163814216)
<br>
![](http://img.blog.csdn.net/20150111163820515)
<br>
![](http://img.blog.csdn.net/20150111164000453)
<br> <br> <br> 
