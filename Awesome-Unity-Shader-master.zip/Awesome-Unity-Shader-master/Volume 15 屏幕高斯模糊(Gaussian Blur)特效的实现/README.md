## Volume 15.屏幕高斯模糊(Gaussian Blur)后期特效的实现
## Gaussian Blur Post Effect

<br>

### 1

![](http://img.blog.csdn.net/20160710153647877)

<br><br>

### 2
![](http://img.blog.csdn.net/20160710154008897)

<br> <br>
### 3
![](http://img.blog.csdn.net/20160710154031224)
