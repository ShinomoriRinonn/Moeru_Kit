
#内容图示

##Volume 03 子着色器、通道与标签的写法 & 纹理混合
<br>
###1. Alpha纹理混合
![](http://img.blog.csdn.net/20141116204632861?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcG9lbV9xaWFubW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
<br> <br> <br> 
###2.纹理的Alpha通道与自发光相混合
![](http://img.blog.csdn.net/20141116204751080?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcG9lbV9xaWFubW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
<br> <br> <br> 
###3. 纹理Alpha与自发光混合可调色版
![](http://img.blog.csdn.net/20141116204937062?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcG9lbV9xaWFubW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
<br> <br> <br> 
###4. 顶点光照+纹理Alpha自发光混合
![](http://img.blog.csdn.net/20141116205146640?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcG9lbV9xaWFubW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
<br> <br> <br> 
###5. 顶点光照+自发光混合+纹理混合
![](http://img.blog.csdn.net/20141116205243876?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcG9lbV9xaWFubW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)