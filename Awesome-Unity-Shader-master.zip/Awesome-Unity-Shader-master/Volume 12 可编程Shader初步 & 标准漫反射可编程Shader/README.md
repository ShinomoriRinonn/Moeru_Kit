
#内容图示

##Volume 12 可编程Shader初步 & 漫反射可编程Shader
<br>
### 1.单色Shader
![](http://img.blog.csdn.net/20160306101527269?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQv/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
<br><br> <br> 

###2.单色可调Shader的书写
![](http://img.blog.csdn.net/20160306101611630?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQv/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)

<br> <br> <br> 
###4.颜色单项可调的RGB Cube
![](http://img.blog.csdn.net/20160306102015714?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQv/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
<br> <br> <br>
###5.三色分量可调的RGB Cube
![](http://img.blog.csdn.net/20160306102053925?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQv/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
<br> <br> <br> 

### 6.单色可调的漫反射光照Shader书写
![](http://img.blog.csdn.net/20160306104333557)
<br> <br> <br> 

### 7.可调颜色和自定义纹理的漫反射光照Shader
![](http://img.blog.csdn.net/20160306104503747)
<br> 
下图是此漫反射Shader使用到皮卡丘模型上的效果图。

  ![](http://img.blog.csdn.net/20160306104520950)

![](http://img.blog.csdn.net/20160306104542279?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQv/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)

![](http://img.blog.csdn.net/20160306104551545?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQv/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)